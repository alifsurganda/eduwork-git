import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://stage.mobipaid.com/en/register')

WebUI.setText(findTestObject('Object Repository/Page_Register/input_Login_signatory_first_name'), 'Alif')

WebUI.setText(findTestObject('Object Repository/Page_Register/input_Login_signatory_last_name'), 'Surganda')

WebUI.setText(findTestObject('Object Repository/Page_Register/input_Login_email'), 'surgandaalif@gmail.com')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_Register/input_Login_password'), '8JanWqnBZBrDwwj0ATxt2A==')

WebUI.setText(findTestObject('Object Repository/Page_Register/input_Login_name'), 'PT XXXX')

WebUI.setText(findTestObject('Object Repository/Page_Register/input_land Islands_form-control btn-log bor_48151b'), '82348338899')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_Register/select_Your country                        _da403c'), 
    '9', true)

WebUI.setText(findTestObject('Object Repository/Page_Register/input_land Islands_state'), 'Jakarta Barat')

WebUI.click(findTestObject('Object Repository/Page_Register/input_By clicking this box, I accept the,an_f76ab8'))

WebUI.click(findTestObject('Object Repository/Page_Register/button_Next Step   please wait'))

WebUI.setText(findTestObject('Object Repository/Page_Register/input_Login_email'), 'asurgandaalif@gmail.com')

WebUI.click(findTestObject('Object Repository/Page_Register/button_Next Step   please wait'))

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/select_Sales person                Search e_941074'), 
    'social_media', true)

WebUI.setText(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/input_Trading As_trading_name'), 'tes')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/select_Select                              _30b3d7'), 
    'public', true)

WebUI.setText(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/textarea_Description of your products or se_3a74f4'), 
    'tes')

WebUI.setText(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/input_Address line 1_company_street_no'), 
    'jakbar')

WebUI.setText(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/input_Address line 2_company_street_name'), 
    'h.saba')

WebUI.setText(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/input_City_company_city'), 'jakarta')

WebUI.setText(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/input_ZIP or Postal Code_company_postal_code'), 
    '55601')

WebUI.click(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/input_Website_company_website'))

WebUI.setText(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/input_Website_company_website'), 'https://stage.mobipaid.com/en/merchant/apply')

WebUI.setText(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/input_Year of incorporation_company_age'), 
    '2023')

WebUI.click(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/button_Next'))

WebUI.setText(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/input_Email_signatory_email'), 'asurgandaalif@gmail.com')

WebUI.setText(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/input_ID Number_signatory_id_number'), 
    '12345')

WebUI.setText(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/input_land Islands_form-control minor-edit _a4e6be'), 
    '82348338899')

WebUI.click(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/input_Same as company address_address_same__59d90d'))

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/select_-- Please Select a country --       _45f784'), 
    'ID', true)

WebUI.click(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/button_Next'))

WebUI.setText(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/input_Account Holder_account_holder'), 
    'tes')

WebUI.setText(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/input_Account Number_account_number'), 
    '12345')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/select_Savings                    Cheque   _bc224e'), 
    'Cheque', true)

WebUI.setText(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/input_Bank_bank'), 'tes')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/select_-- Please select bank country --    _6e0ed3'), 
    'ID', true)

WebUI.setText(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/input_Branch Code or Routing Number_branch_code'), 
    '5')

WebUI.setText(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/input_SwiftBIC_swift_bic'), 'tes')

WebUI.setText(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/textarea_Special Instructions (Optional)_in_1d0905'), 
    'tes')

WebUI.click(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/button_Next'))

WebUI.click(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/button_Skip'))

WebUI.click(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/span_NO'))

WebUI.click(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/button_Next'))

WebUI.click(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/a_Underwriting_20201593595623.pdf'))

WebUI.click(findTestObject('Object Repository/Page_Mobipaid  Merchant Application/button_Apply'))


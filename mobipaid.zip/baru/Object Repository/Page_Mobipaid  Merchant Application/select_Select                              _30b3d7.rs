<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Select                              _30b3d7</name>
   <tag></tag>
   <elementGuidId>af5c861a-904f-4de3-af3c-8abcec6507ce</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#inputCompanyType</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='inputCompanyType']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>61652b52-932a-42fd-9193-888558668b58</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>autocomplete</name>
      <type>Main</type>
      <value>__away</value>
      <webElementGuid>15719793-fc36-45ac-87f0-cf42d9c5882b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control error</value>
      <webElementGuid>e0b9cc4b-2fae-4b7f-8ca5-6d06e6359f0c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>inputCompanyType</value>
      <webElementGuid>c5beb4d5-e3bd-484b-9861-52bb37fd2816</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>company_type</value>
      <webElementGuid>f4d26e2a-0888-4d64-ada1-bb5e6c4f2bd9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>refresh_attachment(this)</value>
      <webElementGuid>9493bbef-897b-4d6b-aae9-03df523c4af1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                Select
                                    Public Company (PTY LTD)
                                    Private Company (LTD)
                                    Non-profit organization
                                    Personal Liability
                                    Company (INC)
                                    Sole Propietorship
                                    Limited Liability Company (LLC)
                                    Local Authority or Government body
                            </value>
      <webElementGuid>a66b9de3-e33d-4041-909e-3cd30fd64753</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;inputCompanyType&quot;)</value>
      <webElementGuid>c81094fe-d7ea-47c4-9424-f114787cb28c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='inputCompanyType']</value>
      <webElementGuid>4ea6d6f3-f330-484f-9a05-79eb6b518b83</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='step-1']/div[2]/div[4]/div/select</value>
      <webElementGuid>73b1491c-97e1-436f-a071-1bc56c48394e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Your company type'])[1]/following::select[1]</value>
      <webElementGuid>ee2b29ed-2bef-41cb-96a6-3cf9dfb58940</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Trading As'])[1]/following::select[1]</value>
      <webElementGuid>adb4ec17-2149-464e-a3d3-c202a5d0bb80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Company Type is required'])[1]/preceding::select[1]</value>
      <webElementGuid>17157bdf-5cee-4468-aba9-b5aba0328abb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Description of your products or services required for payment processing'])[1]/preceding::select[1]</value>
      <webElementGuid>2efbac92-ec21-472d-bdd7-f5e1830ccde3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/select</value>
      <webElementGuid>b641e500-8279-43b4-86f1-ededc6ba3e28</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@id = 'inputCompanyType' and @name = 'company_type' and (text() = '
                Select
                                    Public Company (PTY LTD)
                                    Private Company (LTD)
                                    Non-profit organization
                                    Personal Liability
                                    Company (INC)
                                    Sole Propietorship
                                    Limited Liability Company (LLC)
                                    Local Authority or Government body
                            ' or . = '
                Select
                                    Public Company (PTY LTD)
                                    Private Company (LTD)
                                    Non-profit organization
                                    Personal Liability
                                    Company (INC)
                                    Sole Propietorship
                                    Limited Liability Company (LLC)
                                    Local Authority or Government body
                            ')]</value>
      <webElementGuid>52eb46fc-17bc-43af-96d7-5b0c4d44d489</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

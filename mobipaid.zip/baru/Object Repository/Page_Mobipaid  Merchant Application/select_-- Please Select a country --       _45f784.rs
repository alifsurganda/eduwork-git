<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_-- Please Select a country --       _45f784</name>
   <tag></tag>
   <elementGuidId>2416fd51-ce43-4adc-bbd2-897f984395d2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#inputsignatoryCountry</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='inputsignatoryCountry']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>e71115a4-512c-4cd5-b6d7-71e476d94dcd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>autocomplete</name>
      <type>Main</type>
      <value>__away</value>
      <webElementGuid>e3cc8b68-ac4e-4b6f-b752-a252c157d1c2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>signatory_country</value>
      <webElementGuid>33ff258b-08b7-4d24-9266-59fdcbb322d2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>inputsignatoryCountry</value>
      <webElementGuid>91ae0dcf-8805-4c09-bf4a-a9d3f570f11e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control error</value>
      <webElementGuid>11bfabf4-7ccb-41c8-bf83-d1ececa5b9f8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                -- Please Select a country --
                                    
                        South Africa                    
                                    
                        England                    
                                    
                        United States                    
                                    
                        Afghanistan                    
                                    
                        Aland Islands                    
                                    
                        Albania                    
                                    
                        Algeria                    
                                    
                        American Samoa                    
                                    
                        Andorra                    
                                    
                        Angola                    
                                    
                        Anguilla                    
                                    
                        Antarctica                    
                                    
                        Antigua and Barbuda                    
                                    
                        Argentina                    
                                    
                        Armenia                    
                                    
                        Aruba                    
                                    
                        Australia                    
                                    
                        Austria                    
                                    
                        Azerbaijan                    
                                    
                        Bahamas                    
                                    
                        Bahrain                    
                                    
                        Bangladesh                    
                                    
                        Barbados                    
                                    
                        Belarus                    
                                    
                        Belgium                    
                                    
                        Belize                    
                                    
                        Benin                    
                                    
                        Bermuda                    
                                    
                        Bhutan                    
                                    
                        Bolivia                    
                                    
                        Bonaire, Sint Eustatius and Saba                    
                                    
                        Bosnia and Herzegovina                    
                                    
                        Botswana                    
                                    
                        Bouvet Island                    
                                    
                        Brazil                    
                                    
                        British Indian Ocean Territory                    
                                    
                        Brunei Darussalam                    
                                    
                        Bulgaria                    
                                    
                        Burkina Faso                    
                                    
                        Burundi                    
                                    
                        Cambodia                    
                                    
                        Cameroon                    
                                    
                        Canada                    
                                    
                        Cape Verde                    
                                    
                        Cayman Islands                    
                                    
                        Central African Republic                    
                                    
                        Chad                    
                                    
                        Chile                    
                                    
                        China                    
                                    
                        Christmas Island                    
                                    
                        Cocos (Keeling) Islands                    
                                    
                        Colombia                    
                                    
                        Comoros                    
                                    
                        Congo                    
                                    
                        Congo, the Democratic Republic of the                    
                                    
                        Cook Islands                    
                                    
                        Costa Rica                    
                                    
                        Cote D'Ivoire                    
                                    
                        Croatia                    
                                    
                        Cuba                    
                                    
                        Curaçao                    
                                    
                        Cyprus                    
                                    
                        Czech Republic                    
                                    
                        Denmark                    
                                    
                        Djibouti                    
                                    
                        Dominica                    
                                    
                        Dominican Republic                    
                                    
                        Ecuador                    
                                    
                        Egypt                    
                                    
                        El Salvador                    
                                    
                        Equatorial Guinea                    
                                    
                        Eritrea                    
                                    
                        Estonia                    
                                    
                        Ethiopia                    
                                    
                        Falkland Islands (Malvinas)                    
                                    
                        Faroe Islands                    
                                    
                        Fiji                    
                                    
                        Finland                    
                                    
                        France                    
                                    
                        French Guiana                    
                                    
                        French Polynesia                    
                                    
                        French Southern Territories                    
                                    
                        Gabon                    
                                    
                        Gambia                    
                                    
                        Georgia                    
                                    
                        Germany                    
                                    
                        Ghana                    
                                    
                        Gibraltar                    
                                    
                        Greece                    
                                    
                        Greenland                    
                                    
                        Grenada                    
                                    
                        Guadeloupe                    
                                    
                        Guam                    
                                    
                        Guatemala                    
                                    
                        Guernsey and Alderney                    
                                    
                        Guinea                    
                                    
                        Guinea-Bissau                    
                                    
                        Guyana                    
                                    
                        Haiti                    
                                    
                        Heard Island and Mcdonald Islands                    
                                    
                        Holy See (Vatican City State)                    
                                    
                        Honduras                    
                                    
                        Hong Kong                    
                                    
                        Hungary                    
                                    
                        Iceland                    
                                    
                        India                    
                                    
                        Indonesia                    
                                    
                        Iran, Islamic Republic of                    
                                    
                        Iraq                    
                                    
                        Ireland                    
                                    
                        Israel                    
                                    
                        Italy                    
                                    
                        Jamaica                    
                                    
                        Japan                    
                                    
                        Jersey                    
                                    
                        Jordan                    
                                    
                        Kazakhstan                    
                                    
                        Kenya                    
                                    
                        Kiribati                    
                                    
                        Korea, Democratic People's Republic of                    
                                    
                        Korea, Republic of                    
                                    
                        Kosovo                    
                                    
                        Kuwait                    
                                    
                        Kyrgyzstan                    
                                    
                        Lao People's Democratic Republic                    
                                    
                        Latvia                    
                                    
                        Lebanon                    
                                    
                        Lesotho                    
                                    
                        Liberia                    
                                    
                        Libyan Arab Jamahiriya                    
                                    
                        Liechtenstein                    
                                    
                        Lithuania                    
                                    
                        Luxembourg                    
                                    
                        Macao                    
                                    
                        Macedonia, the Former Yugoslav Republic of                    
                                    
                        Madagascar                    
                                    
                        Malawi                    
                                    
                        Malaysia                    
                                    
                        Maldives                    
                                    
                        Mali                    
                                    
                        Malta                    
                                    
                        Man (Isle of)                    
                                    
                        Marshall Islands                    
                                    
                        Martinique                    
                                    
                        Mauritania                    
                                    
                        Mauritius                    
                                    
                        Mayotte                    
                                    
                        Mexico                    
                                    
                        Micronesia, Federated States of                    
                                    
                        Moldova, Republic of                    
                                    
                        Monaco                    
                                    
                        Mongolia                    
                                    
                        Montenegro                    
                                    
                        Montserrat                    
                                    
                        Morocco                    
                                    
                        Mozambique                    
                                    
                        Myanmar                    
                                    
                        Namibia                    
                                    
                        Nauru                    
                                    
                        Nepal                    
                                    
                        Netherlands                    
                                    
                        Netherlands Antilles                    
                                    
                        New Caledonia                    
                                    
                        New Zealand                    
                                    
                        Nicaragua                    
                                    
                        Niger                    
                                    
                        Nigeria                    
                                    
                        Niue                    
                                    
                        Norfolk Island                    
                                    
                        Northern Ireland                    
                                    
                        Northern Mariana Islands                    
                                    
                        Norway                    
                                    
                        Oman                    
                                    
                        Pakistan                    
                                    
                        Palau                    
                                    
                        Palestinian Territory, Occupied                    
                                    
                        Panama                    
                                    
                        Papua New Guinea                    
                                    
                        Paraguay                    
                                    
                        Peru                    
                                    
                        Philippines                    
                                    
                        Pitcairn                    
                                    
                        Poland                    
                                    
                        Portugal                    
                                    
                        Puerto Rico                    
                                    
                        Qatar                    
                                    
                        Reunion                    
                                    
                        Romania                    
                                    
                        Russian Federation                    
                                    
                        Rwanda                    
                                    
                        Saint Helena                    
                                    
                        Saint Kitts and Nevis                    
                                    
                        Saint Lucia                    
                                    
                        Saint Pierre and Miquelon                    
                                    
                        Saint Vincent and the Grenadines                    
                                    
                        Saint-Barthelemy                    
                                    
                        Saint-Martin (French part)                    
                                    
                        Samoa                    
                                    
                        San Marino                    
                                    
                        Sao Tome and Principe                    
                                    
                        Saudi Arabia                    
                                    
                        Scotland                    
                                    
                        Senegal                    
                                    
                        Serbia                    
                                    
                        Serbia and Montenegro                    
                                    
                        Seychelles                    
                                    
                        Sierra Leone                    
                                    
                        Singapore                    
                                    
                        Sint Maarten (Dutch part)                    
                                    
                        Slovakia                    
                                    
                        Slovenia                    
                                    
                        Solomon Islands                    
                                    
                        Somalia                    
                                    
                        South Georgia and the South Sandwich Islands                    
                                    
                        South Sudan                    
                                    
                        Spain                    
                                    
                        Sri Lanka                    
                                    
                        Sudan                    
                                    
                        Suriname                    
                                    
                        Svalbard and Jan Mayen                    
                                    
                        Swaziland                    
                                    
                        Sweden                    
                                    
                        Switzerland                    
                                    
                        Syrian Arab Republic                    
                                    
                        Taiwan, Province of China                    
                                    
                        Tajikistan                    
                                    
                        Tanzania, United Republic of                    
                                    
                        Thailand                    
                                    
                        Timor-Leste                    
                                    
                        Togo                    
                                    
                        Tokelau                    
                                    
                        Tonga                    
                                    
                        Trinidad and Tobago                    
                                    
                        Tunisia                    
                                    
                        Turkey                    
                                    
                        Turkmenistan                    
                                    
                        Turks and Caicos Islands                    
                                    
                        Tuvalu                    
                                    
                        Uganda                    
                                    
                        Ukraine                    
                                    
                        United Arab Emirates                    
                                    
                        United States Minor Outlying Islands                    
                                    
                        Uruguay                    
                                    
                        Uzbekistan                    
                                    
                        Vanuatu                    
                                    
                        Venezuela                    
                                    
                        Viet Nam                    
                                    
                        Virgin Islands, British                    
                                    
                        Virgin Islands, U.s.                    
                                    
                        Wales                    
                                    
                        Wallis and Futuna                    
                                    
                        Western Sahara                    
                                    
                        Yemen                    
                                    
                        Zambia                    
                                    
                        Zimbabwe                    
                      
            </value>
      <webElementGuid>dd8aaafa-b918-4706-ab10-aadf0997e806</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;inputsignatoryCountry&quot;)</value>
      <webElementGuid>e29724df-d7bc-4231-ab7c-b6672d4be020</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='inputsignatoryCountry']</value>
      <webElementGuid>d2f7a801-9709-4e65-a044-cda2916fc2e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='step-2']/div[2]/div[12]/div/select</value>
      <webElementGuid>3223a7cf-30d5-4df4-97e1-dc88d5ee2d5c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Country'])[2]/following::select[1]</value>
      <webElementGuid>70522c0a-9e34-4cbf-bb49-6d143a5a1e64</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='State / Province / Region'])[2]/following::select[1]</value>
      <webElementGuid>1c05daca-8c56-4d34-b154-4b241fd2839e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Country is required'])[1]/preceding::select[1]</value>
      <webElementGuid>647d829a-1f07-4126-b528-ec10db9cabbe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Optional field'])[2]/preceding::select[1]</value>
      <webElementGuid>19098abf-ad11-4e35-a2fb-599af58618a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[12]/div/select</value>
      <webElementGuid>980347e2-41d7-4f0f-b61d-cfb9b34c6df5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'signatory_country' and @id = 'inputsignatoryCountry' and (text() = concat(&quot;
                -- Please Select a country --
                                    
                        South Africa                    
                                    
                        England                    
                                    
                        United States                    
                                    
                        Afghanistan                    
                                    
                        Aland Islands                    
                                    
                        Albania                    
                                    
                        Algeria                    
                                    
                        American Samoa                    
                                    
                        Andorra                    
                                    
                        Angola                    
                                    
                        Anguilla                    
                                    
                        Antarctica                    
                                    
                        Antigua and Barbuda                    
                                    
                        Argentina                    
                                    
                        Armenia                    
                                    
                        Aruba                    
                                    
                        Australia                    
                                    
                        Austria                    
                                    
                        Azerbaijan                    
                                    
                        Bahamas                    
                                    
                        Bahrain                    
                                    
                        Bangladesh                    
                                    
                        Barbados                    
                                    
                        Belarus                    
                                    
                        Belgium                    
                                    
                        Belize                    
                                    
                        Benin                    
                                    
                        Bermuda                    
                                    
                        Bhutan                    
                                    
                        Bolivia                    
                                    
                        Bonaire, Sint Eustatius and Saba                    
                                    
                        Bosnia and Herzegovina                    
                                    
                        Botswana                    
                                    
                        Bouvet Island                    
                                    
                        Brazil                    
                                    
                        British Indian Ocean Territory                    
                                    
                        Brunei Darussalam                    
                                    
                        Bulgaria                    
                                    
                        Burkina Faso                    
                                    
                        Burundi                    
                                    
                        Cambodia                    
                                    
                        Cameroon                    
                                    
                        Canada                    
                                    
                        Cape Verde                    
                                    
                        Cayman Islands                    
                                    
                        Central African Republic                    
                                    
                        Chad                    
                                    
                        Chile                    
                                    
                        China                    
                                    
                        Christmas Island                    
                                    
                        Cocos (Keeling) Islands                    
                                    
                        Colombia                    
                                    
                        Comoros                    
                                    
                        Congo                    
                                    
                        Congo, the Democratic Republic of the                    
                                    
                        Cook Islands                    
                                    
                        Costa Rica                    
                                    
                        Cote D&quot; , &quot;'&quot; , &quot;Ivoire                    
                                    
                        Croatia                    
                                    
                        Cuba                    
                                    
                        Curaçao                    
                                    
                        Cyprus                    
                                    
                        Czech Republic                    
                                    
                        Denmark                    
                                    
                        Djibouti                    
                                    
                        Dominica                    
                                    
                        Dominican Republic                    
                                    
                        Ecuador                    
                                    
                        Egypt                    
                                    
                        El Salvador                    
                                    
                        Equatorial Guinea                    
                                    
                        Eritrea                    
                                    
                        Estonia                    
                                    
                        Ethiopia                    
                                    
                        Falkland Islands (Malvinas)                    
                                    
                        Faroe Islands                    
                                    
                        Fiji                    
                                    
                        Finland                    
                                    
                        France                    
                                    
                        French Guiana                    
                                    
                        French Polynesia                    
                                    
                        French Southern Territories                    
                                    
                        Gabon                    
                                    
                        Gambia                    
                                    
                        Georgia                    
                                    
                        Germany                    
                                    
                        Ghana                    
                                    
                        Gibraltar                    
                                    
                        Greece                    
                                    
                        Greenland                    
                                    
                        Grenada                    
                                    
                        Guadeloupe                    
                                    
                        Guam                    
                                    
                        Guatemala                    
                                    
                        Guernsey and Alderney                    
                                    
                        Guinea                    
                                    
                        Guinea-Bissau                    
                                    
                        Guyana                    
                                    
                        Haiti                    
                                    
                        Heard Island and Mcdonald Islands                    
                                    
                        Holy See (Vatican City State)                    
                                    
                        Honduras                    
                                    
                        Hong Kong                    
                                    
                        Hungary                    
                                    
                        Iceland                    
                                    
                        India                    
                                    
                        Indonesia                    
                                    
                        Iran, Islamic Republic of                    
                                    
                        Iraq                    
                                    
                        Ireland                    
                                    
                        Israel                    
                                    
                        Italy                    
                                    
                        Jamaica                    
                                    
                        Japan                    
                                    
                        Jersey                    
                                    
                        Jordan                    
                                    
                        Kazakhstan                    
                                    
                        Kenya                    
                                    
                        Kiribati                    
                                    
                        Korea, Democratic People&quot; , &quot;'&quot; , &quot;s Republic of                    
                                    
                        Korea, Republic of                    
                                    
                        Kosovo                    
                                    
                        Kuwait                    
                                    
                        Kyrgyzstan                    
                                    
                        Lao People&quot; , &quot;'&quot; , &quot;s Democratic Republic                    
                                    
                        Latvia                    
                                    
                        Lebanon                    
                                    
                        Lesotho                    
                                    
                        Liberia                    
                                    
                        Libyan Arab Jamahiriya                    
                                    
                        Liechtenstein                    
                                    
                        Lithuania                    
                                    
                        Luxembourg                    
                                    
                        Macao                    
                                    
                        Macedonia, the Former Yugoslav Republic of                    
                                    
                        Madagascar                    
                                    
                        Malawi                    
                                    
                        Malaysia                    
                                    
                        Maldives                    
                                    
                        Mali                    
                                    
                        Malta                    
                                    
                        Man (Isle of)                    
                                    
                        Marshall Islands                    
                                    
                        Martinique                    
                                    
                        Mauritania                    
                                    
                        Mauritius                    
                                    
                        Mayotte                    
                                    
                        Mexico                    
                                    
                        Micronesia, Federated States of                    
                                    
                        Moldova, Republic of                    
                                    
                        Monaco                    
                                    
                        Mongolia                    
                                    
                        Montenegro                    
                                    
                        Montserrat                    
                                    
                        Morocco                    
                                    
                        Mozambique                    
                                    
                        Myanmar                    
                                    
                        Namibia                    
                                    
                        Nauru                    
                                    
                        Nepal                    
                                    
                        Netherlands                    
                                    
                        Netherlands Antilles                    
                                    
                        New Caledonia                    
                                    
                        New Zealand                    
                                    
                        Nicaragua                    
                                    
                        Niger                    
                                    
                        Nigeria                    
                                    
                        Niue                    
                                    
                        Norfolk Island                    
                                    
                        Northern Ireland                    
                                    
                        Northern Mariana Islands                    
                                    
                        Norway                    
                                    
                        Oman                    
                                    
                        Pakistan                    
                                    
                        Palau                    
                                    
                        Palestinian Territory, Occupied                    
                                    
                        Panama                    
                                    
                        Papua New Guinea                    
                                    
                        Paraguay                    
                                    
                        Peru                    
                                    
                        Philippines                    
                                    
                        Pitcairn                    
                                    
                        Poland                    
                                    
                        Portugal                    
                                    
                        Puerto Rico                    
                                    
                        Qatar                    
                                    
                        Reunion                    
                                    
                        Romania                    
                                    
                        Russian Federation                    
                                    
                        Rwanda                    
                                    
                        Saint Helena                    
                                    
                        Saint Kitts and Nevis                    
                                    
                        Saint Lucia                    
                                    
                        Saint Pierre and Miquelon                    
                                    
                        Saint Vincent and the Grenadines                    
                                    
                        Saint-Barthelemy                    
                                    
                        Saint-Martin (French part)                    
                                    
                        Samoa                    
                                    
                        San Marino                    
                                    
                        Sao Tome and Principe                    
                                    
                        Saudi Arabia                    
                                    
                        Scotland                    
                                    
                        Senegal                    
                                    
                        Serbia                    
                                    
                        Serbia and Montenegro                    
                                    
                        Seychelles                    
                                    
                        Sierra Leone                    
                                    
                        Singapore                    
                                    
                        Sint Maarten (Dutch part)                    
                                    
                        Slovakia                    
                                    
                        Slovenia                    
                                    
                        Solomon Islands                    
                                    
                        Somalia                    
                                    
                        South Georgia and the South Sandwich Islands                    
                                    
                        South Sudan                    
                                    
                        Spain                    
                                    
                        Sri Lanka                    
                                    
                        Sudan                    
                                    
                        Suriname                    
                                    
                        Svalbard and Jan Mayen                    
                                    
                        Swaziland                    
                                    
                        Sweden                    
                                    
                        Switzerland                    
                                    
                        Syrian Arab Republic                    
                                    
                        Taiwan, Province of China                    
                                    
                        Tajikistan                    
                                    
                        Tanzania, United Republic of                    
                                    
                        Thailand                    
                                    
                        Timor-Leste                    
                                    
                        Togo                    
                                    
                        Tokelau                    
                                    
                        Tonga                    
                                    
                        Trinidad and Tobago                    
                                    
                        Tunisia                    
                                    
                        Turkey                    
                                    
                        Turkmenistan                    
                                    
                        Turks and Caicos Islands                    
                                    
                        Tuvalu                    
                                    
                        Uganda                    
                                    
                        Ukraine                    
                                    
                        United Arab Emirates                    
                                    
                        United States Minor Outlying Islands                    
                                    
                        Uruguay                    
                                    
                        Uzbekistan                    
                                    
                        Vanuatu                    
                                    
                        Venezuela                    
                                    
                        Viet Nam                    
                                    
                        Virgin Islands, British                    
                                    
                        Virgin Islands, U.s.                    
                                    
                        Wales                    
                                    
                        Wallis and Futuna                    
                                    
                        Western Sahara                    
                                    
                        Yemen                    
                                    
                        Zambia                    
                                    
                        Zimbabwe                    
                      
            &quot;) or . = concat(&quot;
                -- Please Select a country --
                                    
                        South Africa                    
                                    
                        England                    
                                    
                        United States                    
                                    
                        Afghanistan                    
                                    
                        Aland Islands                    
                                    
                        Albania                    
                                    
                        Algeria                    
                                    
                        American Samoa                    
                                    
                        Andorra                    
                                    
                        Angola                    
                                    
                        Anguilla                    
                                    
                        Antarctica                    
                                    
                        Antigua and Barbuda                    
                                    
                        Argentina                    
                                    
                        Armenia                    
                                    
                        Aruba                    
                                    
                        Australia                    
                                    
                        Austria                    
                                    
                        Azerbaijan                    
                                    
                        Bahamas                    
                                    
                        Bahrain                    
                                    
                        Bangladesh                    
                                    
                        Barbados                    
                                    
                        Belarus                    
                                    
                        Belgium                    
                                    
                        Belize                    
                                    
                        Benin                    
                                    
                        Bermuda                    
                                    
                        Bhutan                    
                                    
                        Bolivia                    
                                    
                        Bonaire, Sint Eustatius and Saba                    
                                    
                        Bosnia and Herzegovina                    
                                    
                        Botswana                    
                                    
                        Bouvet Island                    
                                    
                        Brazil                    
                                    
                        British Indian Ocean Territory                    
                                    
                        Brunei Darussalam                    
                                    
                        Bulgaria                    
                                    
                        Burkina Faso                    
                                    
                        Burundi                    
                                    
                        Cambodia                    
                                    
                        Cameroon                    
                                    
                        Canada                    
                                    
                        Cape Verde                    
                                    
                        Cayman Islands                    
                                    
                        Central African Republic                    
                                    
                        Chad                    
                                    
                        Chile                    
                                    
                        China                    
                                    
                        Christmas Island                    
                                    
                        Cocos (Keeling) Islands                    
                                    
                        Colombia                    
                                    
                        Comoros                    
                                    
                        Congo                    
                                    
                        Congo, the Democratic Republic of the                    
                                    
                        Cook Islands                    
                                    
                        Costa Rica                    
                                    
                        Cote D&quot; , &quot;'&quot; , &quot;Ivoire                    
                                    
                        Croatia                    
                                    
                        Cuba                    
                                    
                        Curaçao                    
                                    
                        Cyprus                    
                                    
                        Czech Republic                    
                                    
                        Denmark                    
                                    
                        Djibouti                    
                                    
                        Dominica                    
                                    
                        Dominican Republic                    
                                    
                        Ecuador                    
                                    
                        Egypt                    
                                    
                        El Salvador                    
                                    
                        Equatorial Guinea                    
                                    
                        Eritrea                    
                                    
                        Estonia                    
                                    
                        Ethiopia                    
                                    
                        Falkland Islands (Malvinas)                    
                                    
                        Faroe Islands                    
                                    
                        Fiji                    
                                    
                        Finland                    
                                    
                        France                    
                                    
                        French Guiana                    
                                    
                        French Polynesia                    
                                    
                        French Southern Territories                    
                                    
                        Gabon                    
                                    
                        Gambia                    
                                    
                        Georgia                    
                                    
                        Germany                    
                                    
                        Ghana                    
                                    
                        Gibraltar                    
                                    
                        Greece                    
                                    
                        Greenland                    
                                    
                        Grenada                    
                                    
                        Guadeloupe                    
                                    
                        Guam                    
                                    
                        Guatemala                    
                                    
                        Guernsey and Alderney                    
                                    
                        Guinea                    
                                    
                        Guinea-Bissau                    
                                    
                        Guyana                    
                                    
                        Haiti                    
                                    
                        Heard Island and Mcdonald Islands                    
                                    
                        Holy See (Vatican City State)                    
                                    
                        Honduras                    
                                    
                        Hong Kong                    
                                    
                        Hungary                    
                                    
                        Iceland                    
                                    
                        India                    
                                    
                        Indonesia                    
                                    
                        Iran, Islamic Republic of                    
                                    
                        Iraq                    
                                    
                        Ireland                    
                                    
                        Israel                    
                                    
                        Italy                    
                                    
                        Jamaica                    
                                    
                        Japan                    
                                    
                        Jersey                    
                                    
                        Jordan                    
                                    
                        Kazakhstan                    
                                    
                        Kenya                    
                                    
                        Kiribati                    
                                    
                        Korea, Democratic People&quot; , &quot;'&quot; , &quot;s Republic of                    
                                    
                        Korea, Republic of                    
                                    
                        Kosovo                    
                                    
                        Kuwait                    
                                    
                        Kyrgyzstan                    
                                    
                        Lao People&quot; , &quot;'&quot; , &quot;s Democratic Republic                    
                                    
                        Latvia                    
                                    
                        Lebanon                    
                                    
                        Lesotho                    
                                    
                        Liberia                    
                                    
                        Libyan Arab Jamahiriya                    
                                    
                        Liechtenstein                    
                                    
                        Lithuania                    
                                    
                        Luxembourg                    
                                    
                        Macao                    
                                    
                        Macedonia, the Former Yugoslav Republic of                    
                                    
                        Madagascar                    
                                    
                        Malawi                    
                                    
                        Malaysia                    
                                    
                        Maldives                    
                                    
                        Mali                    
                                    
                        Malta                    
                                    
                        Man (Isle of)                    
                                    
                        Marshall Islands                    
                                    
                        Martinique                    
                                    
                        Mauritania                    
                                    
                        Mauritius                    
                                    
                        Mayotte                    
                                    
                        Mexico                    
                                    
                        Micronesia, Federated States of                    
                                    
                        Moldova, Republic of                    
                                    
                        Monaco                    
                                    
                        Mongolia                    
                                    
                        Montenegro                    
                                    
                        Montserrat                    
                                    
                        Morocco                    
                                    
                        Mozambique                    
                                    
                        Myanmar                    
                                    
                        Namibia                    
                                    
                        Nauru                    
                                    
                        Nepal                    
                                    
                        Netherlands                    
                                    
                        Netherlands Antilles                    
                                    
                        New Caledonia                    
                                    
                        New Zealand                    
                                    
                        Nicaragua                    
                                    
                        Niger                    
                                    
                        Nigeria                    
                                    
                        Niue                    
                                    
                        Norfolk Island                    
                                    
                        Northern Ireland                    
                                    
                        Northern Mariana Islands                    
                                    
                        Norway                    
                                    
                        Oman                    
                                    
                        Pakistan                    
                                    
                        Palau                    
                                    
                        Palestinian Territory, Occupied                    
                                    
                        Panama                    
                                    
                        Papua New Guinea                    
                                    
                        Paraguay                    
                                    
                        Peru                    
                                    
                        Philippines                    
                                    
                        Pitcairn                    
                                    
                        Poland                    
                                    
                        Portugal                    
                                    
                        Puerto Rico                    
                                    
                        Qatar                    
                                    
                        Reunion                    
                                    
                        Romania                    
                                    
                        Russian Federation                    
                                    
                        Rwanda                    
                                    
                        Saint Helena                    
                                    
                        Saint Kitts and Nevis                    
                                    
                        Saint Lucia                    
                                    
                        Saint Pierre and Miquelon                    
                                    
                        Saint Vincent and the Grenadines                    
                                    
                        Saint-Barthelemy                    
                                    
                        Saint-Martin (French part)                    
                                    
                        Samoa                    
                                    
                        San Marino                    
                                    
                        Sao Tome and Principe                    
                                    
                        Saudi Arabia                    
                                    
                        Scotland                    
                                    
                        Senegal                    
                                    
                        Serbia                    
                                    
                        Serbia and Montenegro                    
                                    
                        Seychelles                    
                                    
                        Sierra Leone                    
                                    
                        Singapore                    
                                    
                        Sint Maarten (Dutch part)                    
                                    
                        Slovakia                    
                                    
                        Slovenia                    
                                    
                        Solomon Islands                    
                                    
                        Somalia                    
                                    
                        South Georgia and the South Sandwich Islands                    
                                    
                        South Sudan                    
                                    
                        Spain                    
                                    
                        Sri Lanka                    
                                    
                        Sudan                    
                                    
                        Suriname                    
                                    
                        Svalbard and Jan Mayen                    
                                    
                        Swaziland                    
                                    
                        Sweden                    
                                    
                        Switzerland                    
                                    
                        Syrian Arab Republic                    
                                    
                        Taiwan, Province of China                    
                                    
                        Tajikistan                    
                                    
                        Tanzania, United Republic of                    
                                    
                        Thailand                    
                                    
                        Timor-Leste                    
                                    
                        Togo                    
                                    
                        Tokelau                    
                                    
                        Tonga                    
                                    
                        Trinidad and Tobago                    
                                    
                        Tunisia                    
                                    
                        Turkey                    
                                    
                        Turkmenistan                    
                                    
                        Turks and Caicos Islands                    
                                    
                        Tuvalu                    
                                    
                        Uganda                    
                                    
                        Ukraine                    
                                    
                        United Arab Emirates                    
                                    
                        United States Minor Outlying Islands                    
                                    
                        Uruguay                    
                                    
                        Uzbekistan                    
                                    
                        Vanuatu                    
                                    
                        Venezuela                    
                                    
                        Viet Nam                    
                                    
                        Virgin Islands, British                    
                                    
                        Virgin Islands, U.s.                    
                                    
                        Wales                    
                                    
                        Wallis and Futuna                    
                                    
                        Western Sahara                    
                                    
                        Yemen                    
                                    
                        Zambia                    
                                    
                        Zimbabwe                    
                      
            &quot;))]</value>
      <webElementGuid>053e0487-fef4-45dd-9e67-068f2229d975</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Sales person                Search e_941074</name>
   <tag></tag>
   <elementGuidId>67657817-53b1-4a06-8158-2b831effa927</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#referral_type</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='referral_type']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>6a143776-c9e4-46a8-8f4c-5e480aed3ad5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>autocomplete</name>
      <type>Main</type>
      <value>__away</value>
      <webElementGuid>cf1b02ad-9d0a-44c6-a3fb-8535feaef0e6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control mrgn-bot-vs</value>
      <webElementGuid>6da8120f-2308-4c31-ab6d-cafc7b72785f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>referral_type</value>
      <webElementGuid>2728ed68-a5c6-41dd-98e3-e5103f70ca89</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>referral_type</value>
      <webElementGuid>7bd5b3a2-8d6e-4ee9-9e70-604985ac841d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                Sales person
                Search engine
                Social Media
                Other
            </value>
      <webElementGuid>217c6d95-db81-4ab6-9959-4bafb4e9d985</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;referral_type&quot;)</value>
      <webElementGuid>7406f7e7-6749-4174-b7b1-0f488d9e129d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='referral_type']</value>
      <webElementGuid>0449d972-3941-41b8-a356-f3c923a5409f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='step-1']/div[2]/div/div/select</value>
      <webElementGuid>6027e546-f1d4-4e49-8471-671d015b0c2e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Referral'])[1]/following::select[1]</value>
      <webElementGuid>f6487838-4f49-4f60-9ef5-0a3341cf85e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Company Information'])[2]/following::select[1]</value>
      <webElementGuid>a51f83ef-277e-4f03-9905-2817aef21c0a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Referral is required'])[1]/preceding::select[1]</value>
      <webElementGuid>d4b1b47c-7842-42ad-8671-5c53b474f59f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Company or Business Name'])[1]/preceding::select[3]</value>
      <webElementGuid>ef8930b6-80b6-4513-a866-4ab27b334b94</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>49972a7c-587d-467e-a2a6-91a8de18925b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@id = 'referral_type' and @name = 'referral_type' and (text() = '
                Sales person
                Search engine
                Social Media
                Other
            ' or . = '
                Sales person
                Search engine
                Social Media
                Other
            ')]</value>
      <webElementGuid>35c7455b-6350-43fa-99e0-3ffbeb6ef9d4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Your country                        _da403c</name>
   <tag></tag>
   <elementGuidId>8190c402-a263-4663-946b-b11f1d48c485</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#country</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='country']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>8e2b1729-5f4c-48f3-9722-41d09eda4339</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>region</value>
      <webElementGuid>f175e44a-7977-4e05-9a65-6cec28ae0b29</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control border-grey</value>
      <webElementGuid>6ee79b18-6fb0-44b3-a801-d902ce33204c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>country</value>
      <webElementGuid>7c2aad27-9789-4699-9b86-d61e4f6f123c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>handle_state_change()</value>
      <webElementGuid>b21052e6-c7ba-43c4-a6b5-7c5675648172</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                  Your country
                                       
                      South Africa                    
                                       
                      South Africa nedbank                    
                                       
                      United states                    
                                       
                      irlandia                    
                                       
                      Europe                    
                                       
                      Indonesia                    
                                       
                      Japan                    
                                       
                      Wakanda                    
                                       
                      testnew                    
                                       
                      test123                    
                                  </value>
      <webElementGuid>0b8a9242-aefc-425d-8a10-6be69b623803</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;country&quot;)</value>
      <webElementGuid>27afee95-7d79-4d42-8039-d69d62138981</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='country']</value>
      <webElementGuid>09819a84-77fb-4531-9de5-dabc693591be</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='formRegister']/div[5]/div[3]/select</value>
      <webElementGuid>7b1c8488-5da7-4a3c-8521-5fd5652940df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Åland Islands'])[1]/following::select[1]</value>
      <webElementGuid>dc142c0d-9037-482a-a3dd-130b72aea014</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Zimbabwe'])[1]/following::select[1]</value>
      <webElementGuid>a4634927-7b9f-4ff3-9852-15c6b0998e7d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Payment Services Agreement'])[1]/preceding::select[2]</value>
      <webElementGuid>4c43fda7-a644-4433-a574-01a0aa8ca8fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div[3]/select</value>
      <webElementGuid>fa16b014-c782-490a-a974-66776a89c85e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'region' and @id = 'country' and (text() = '
                  Your country
                                       
                      South Africa                    
                                       
                      South Africa nedbank                    
                                       
                      United states                    
                                       
                      irlandia                    
                                       
                      Europe                    
                                       
                      Indonesia                    
                                       
                      Japan                    
                                       
                      Wakanda                    
                                       
                      testnew                    
                                       
                      test123                    
                                  ' or . = '
                  Your country
                                       
                      South Africa                    
                                       
                      South Africa nedbank                    
                                       
                      United states                    
                                       
                      irlandia                    
                                       
                      Europe                    
                                       
                      Indonesia                    
                                       
                      Japan                    
                                       
                      Wakanda                    
                                       
                      testnew                    
                                       
                      test123                    
                                  ')]</value>
      <webElementGuid>7899cc54-7806-4249-8bea-ce3101b436d6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
